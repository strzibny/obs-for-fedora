class ServiceController < ApplicationController

  def index
    pass_to_backend 
  end

  def index_service
    pass_to_backend 
  end

end
