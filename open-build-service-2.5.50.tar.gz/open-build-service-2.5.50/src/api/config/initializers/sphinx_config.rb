# This shouldn't be needed anymore when thinking-sphinx bugs are fixed
ThinkingSphinx::Configuration::Defaults::PANES << ThinkingSphinx::Panes::AttributesPane
