This is Restility, a set of tools for writing REST style web services.

Feel free to contact the author Cornelius Schumacher <cschum@suse.de>, if you
have questions or comments.
